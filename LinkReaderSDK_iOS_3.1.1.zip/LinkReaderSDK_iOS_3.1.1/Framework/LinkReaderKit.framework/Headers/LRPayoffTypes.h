//
//  LRPayoffTypes.h
//  LinkReaderSDK
//
//  Copyright (c) 2015 HP. All rights reserved.
//

#import <LinkReaderKit/LRPayoff.h>
#import <LinkReaderKit/LRLayoutPayoff.h>
#import <LinkReaderKit/LRSharePayoff.h>
#import <LinkReaderKit/LREmailPayoff.h>
#import <LinkReaderKit/LRContactPayoff.h>
#import <LinkReaderKit/LRCalendarEventPayoff.h>
#import <LinkReaderKit/LRSmsPayoff.h>
#import <LinkReaderKit/LRMmsPayoff.h>
#import <LinkReaderKit/LRPhoneCallPayoff.h>
#import <LinkReaderKit/LRWebPayoff.h>
#import <LinkReaderKit/LRLocationPayoff.h>
#import <LinkReaderKit/LREnhancedWebPayoff.h>
#import <LinkReaderKit/LRCustomDataPayoff.h>
#import <LinkReaderKit/LRHtmlPayoff.h>
