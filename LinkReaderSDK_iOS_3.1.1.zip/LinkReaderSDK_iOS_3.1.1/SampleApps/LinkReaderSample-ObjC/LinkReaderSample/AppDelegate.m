//
//  AppDelegate.m
//  LinkReaderSample
//
//  Created by Live Paper Pairing on 5/5/15.
//  Copyright (c) 2015 HP. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    return YES;
}

@end
